package com.weartak.plugin.sdk.transport.model;
parcelable TransportDeliveryParcel;
