package com.weartak.plugin.sdk.transport

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import com.weartak.plugin.sdk.model.PluginInitParcel
import com.weartak.plugin.sdk.transport.aidl.IPluginTransportCallbackV1
import com.weartak.plugin.sdk.transport.aidl.IPluginTransportHostV1
import com.weartak.plugin.sdk.transport.model.TransportCapabilitiesParcel
import com.weartak.plugin.sdk.transport.model.TransportDeliveryParcel
import com.weartak.plugin.sdk.transport.model.TransportMessageParcel
import com.weartak.plugin.sdk.transport.model.TransportResultParcel
import com.weartak.plugin.sdk.transport.model.TransportSendRequestParcel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File
import kotlinx.parcelize.parcelableCreator

@RunWith(RobolectricTestRunner::class)
class TransportContractTest {
    private val caps = TransportCapabilitiesParcel(
        outboundPayloadKinds = listOf(1, 2),
        inboundPayloadKinds = listOf(1, 2),
        channelIds = listOf("radio"),
        runtimeAvailable = true,
        deviceReceipts = true,
        recipientReceipts = true,
    )
    private fun message(id: String = "m1", payload: ByteArray = "hello".toByteArray()) =
        TransportMessageParcel(id, 1, payload, "tak-sender", "tak-recipient", "Alpha", "workspace", "18446744073709551615", 1700000000123)
    private fun request(id: String = "m1", channel: String = "radio", deadline: Long = 2000) =
        TransportSendRequestParcel("s1", channel, message(id), deadline)
    private fun session(capabilities: TransportCapabilitiesParcel = caps, clock: () -> Long = { 1000 }) =
        TransportSession("s1", 42, capabilities, clock)
    private fun assertCode(expected: Int, value: TransportResultParcel) = assertEquals(value.detail, expected, value.code)
    private fun update(stage: Int, sequence: Long = stage.toLong(), channel: String = "radio") =
        TransportDeliveryParcel("m1", channel, sequence, stage, if (stage == 5) "channel-error" else null)

    @Test
    fun boundariesAndMalformedUtf8() {
        assertCode(0, TransportValidator.message(message(payload = ByteArray(49152) { 65 }), caps, true))
        assertCode(4, TransportValidator.message(message(payload = ByteArray(49153) { 65 }), caps, true))
        assertCode(4, TransportValidator.message(message(payload = ByteArray(100) { 65 }), caps.copy(maxPayloadBytes = 99), true))
        assertCode(1, TransportValidator.message(message(payload = byteArrayOf(0xc3.toByte(), 0x28)), caps, true))
        assertCode(1, TransportValidator.message(message(payload = "x\u0000y".toByteArray()), caps, true))
        assertCode(1, TransportValidator.message(message(payload = " ".toByteArray()), caps, true))
        assertTrue(TransportValidator.id("A".repeat(128)))
        assertFalse(TransportValidator.id("A".repeat(129)))
        assertFalse(TransportValidator.id("\u00e9".repeat(65)))
        assertFalse(TransportValidator.id("bad\nid"))
        assertCode(1, TransportValidator.message(message().copy(externalId = ""), caps, true))
        assertCode(0, TransportValidator.message(message().copy(sentAtEpochMillis = null), caps, true))
        assertCode(0, TransportValidator.message(message().copy(sentAtEpochMillis = 0), caps, true))
        assertCode(0, TransportValidator.message(message().copy(sentAtEpochMillis = TransportContract.MAX_SENT_AT_EPOCH_MILLIS), caps, true))
        assertCode(1, TransportValidator.message(message().copy(sentAtEpochMillis = -1), caps, true))
        assertCode(1, TransportValidator.message(message().copy(sentAtEpochMillis = TransportContract.MAX_SENT_AT_EPOCH_MILLIS + 1), caps, true))
    }

    @Test
    fun capabilitiesAreStrictAndDirectional() {
        assertCode(8, TransportValidator.capabilities(caps.copy(version = 2)))
        assertCode(1, TransportValidator.capabilities(caps.copy(channelIds = List(9) { "c$it" })))
        assertCode(1, TransportValidator.capabilities(caps.copy(channelIds = listOf("radio", "radio"))))
        assertCode(1, TransportValidator.capabilities(caps.copy(maxPendingMessages = 33)))
        assertCode(1, TransportValidator.capabilities(caps.copy(outboundPayloadKinds = listOf(1, 1))))
        assertCode(1, TransportValidator.capabilities(caps.copy(channelIds = emptyList())))
        assertCode(0, TransportValidator.capabilities(caps.copy(channelIds = emptyList()), host = true))
        assertCode(8, session(caps.copy(outboundPayloadKinds = emptyList())).admitOutbound(request(), 42))
        assertCode(8, session(caps.copy(inboundPayloadKinds = emptyList())).admitInbound("s1", "radio", message(), 42))
        assertCode(9, session(caps.copy(runtimeAvailable = false)).admitOutbound(request(), 42))
        assertCode(8, session().admitOutbound(request(channel = "satellite"), 42))
    }

    @Test
    fun uidSessionLifecycleAndDuplicateFences() {
        val state = session()
        assertCode(2, state.admitOutbound(request(), 43))
        assertCode(3, state.admitOutbound(request().copy(sessionId = "old"), 42))
        assertCode(0, state.admitOutbound(request(), 42))
        assertCode(5, state.admitOutbound(request(), 42))
        assertCode(5, state.admitInbound("s1", "radio", message(), 42))
        assertCode(0, state.admitInbound("s1", "radio", message("incoming"), 42))
        assertCode(5, state.admitInbound("s1", "radio", message("incoming"), 42))
        assertCode(5, state.admitOutbound(request("incoming"), 42))
        assertCode(2, state.delivery("s1", update(1), 43))
        assertCode(3, state.delivery("old", update(1), 42))
        assertEquals(listOf("m1"), state.close())
        assertCode(3, state.admitOutbound(request("new"), 42))
        assertCode(3, state.admitInbound("s1", "radio", message("new"), 42))
        assertCode(3, state.delivery("s1", update(2), 42))
        assertCode(3, state.cancel("s1", "m1", 42))
        assertTrue(state.close().isEmpty())
    }

    @Test
    fun receiptsRequireScopeCorrelationAndMonotonicity() {
        val state = session()
        assertCode(6, state.delivery("s1", update(1), 42))
        assertCode(0, state.admitOutbound(request(), 42))
        assertCode(1, state.delivery("s1", update(1, channel = "wrong"), 42))
        assertCode(0, state.delivery("s1", update(1), 42))
        assertCode(7, state.delivery("s1", update(1), 42))
        assertCode(0, state.delivery("s1", update(2), 42))
        assertCode(7, state.delivery("s1", update(1, 3), 42))
        assertCode(0, state.delivery("s1", update(3), 42))
        assertCode(0, state.delivery("s1", update(4), 42))
        assertCode(7, state.delivery("s1", update(5, 5), 42))
        val noReceipts = session(caps.copy(deviceReceipts = false, recipientReceipts = false))
        assertCode(0, noReceipts.admitOutbound(request(), 42))
        assertCode(8, noReceipts.delivery("s1", update(3), 42))
        assertCode(8, noReceipts.delivery("s1", update(4), 42))
        assertCode(0, noReceipts.delivery("s1", update(2), 42))
        val deviceOnly = session(caps.copy(recipientReceipts = false))
        assertCode(0, deviceOnly.admitOutbound(request(), 42))
        assertCode(0, deviceOnly.delivery("s1", update(3), 42))
        assertCode(7, deviceOnly.delivery("s1", update(4), 42))
        assertCode(1, TransportValidator.delivery(update(5).copy(errorCode = null)))
        assertCode(1, TransportValidator.delivery(update(3).copy(errorCode = "error")))
        assertCode(1, TransportValidator.delivery(update(2).copy(sequence = 0)))
        assertCode(1, TransportValidator.delivery(update(2).copy(detail = "x".repeat(257))))
    }

    @Test
    fun pendingBoundCancellationExpirationAndFailClosedHistory() {
        var now = 1000L
        val state = session(caps.copy(maxPendingMessages = 1)) { now }
        assertCode(10, state.admitOutbound(request(deadline = now), 42))
        assertCode(1, state.admitOutbound(request(deadline = now + TransportContract.MAX_DEADLINE_MS + 1), 42))
        assertCode(0, state.admitOutbound(request(), 42))
        assertCode(4, state.admitOutbound(request("m2"), 42))
        assertCode(0, state.cancel("s1", "m1", 42))
        assertCode(7, state.delivery("s1", update(3), 42))
        assertCode(0, state.admitOutbound(request("m2"), 42))
        now = 2000
        assertCode(10, state.delivery("s1", update(2).copy(messageId = "m2"), 42))
        assertEquals(listOf("m2"), state.expire())
        assertTrue(state.expire().isEmpty())
        assertCode(5, state.admitOutbound(request("m2", deadline = 3000), 42))
        repeat(254) { assertCode(0, state.admitInbound("s1", "radio", message("in$it"), 42)) }
        assertCode(4, state.admitInbound("s1", "radio", message("overflow"), 42))
        assertCode(5, state.admitInbound("s1", "radio", message("in0"), 42))
    }

    @Suppress("DEPRECATION")
    private inline fun <reified T : Parcelable> roundTrip(value: T): T {
        val parcel = Parcel.obtain()
        try {
            parcel.writeParcelable(value, 0)
            parcel.setDataPosition(0)
            return requireNotNull(parcel.readParcelable<T>(T::class.java.classLoader))
        } finally {
            parcel.recycle()
        }
    }

    @Test
    fun parcelRoundTripsPreserveOpaqueIdsAndFields() {
        val original = message(payload = ByteArray(49152) { 65 })
        val restored = roundTrip(original)
        assertArrayEquals(original.payload, restored.payload)
        assertEquals(original.externalId, restored.externalId)
        assertEquals(original.senderCallsign, restored.senderCallsign)
        assertEquals(original.senderUid, restored.senderUid)
        assertEquals(original.recipientUid, restored.recipientUid)
        assertEquals(original.workspaceId, restored.workspaceId)
        assertEquals(original.sentAtEpochMillis, restored.sentAtEpochMillis)
        assertEquals(caps, roundTrip(caps))
        val ordered = caps.copy(channelIds = listOf("preferred", "fallback"))
        assertCode(0, TransportValidator.capabilities(ordered))
        assertEquals(ordered.channelIds, roundTrip(ordered).channelIds)
        assertEquals(update(5), roundTrip(update(5)))
        assertEquals(TransportResultParcel(4, "s1", "capacity"), roundTrip(TransportResultParcel(4, "s1", "capacity")))
        val restoredRequest = roundTrip(request())
        assertEquals("s1", restoredRequest.sessionId)
        assertEquals(2000L, restoredRequest.deadlineEpochMillis)
        val parcel = Parcel.obtain()
        try {
            parcel.writeParcelable(TransportSendRequestParcel("s1", "radio", original, 2000), 0)
            assertTrue("Single request fits far below Binder shared budget", parcel.dataSize() < 64 * 1024)
        } finally { parcel.recycle() }
    }

    @Test
    fun optionalDiscoveryAndBinderRoundTrip() {
        val state = session()
        val callback = object : IPluginTransportCallbackV1.Stub() {
            override fun sendMessage(request: TransportSendRequestParcel?) =
                if (request == null) TransportResultParcel(1) else state.admitOutbound(request, 42)
            override fun cancelMessage(sessionId: String?, messageId: String?) =
                state.cancel(sessionId.orEmpty(), messageId.orEmpty(), 42)
            override fun onSessionClosed(sessionId: String?, reason: Int) { state.close() }
        }
        val host = object : IPluginTransportHostV1.Stub() {
            override fun getHostCapabilities() = caps
            override fun registerTransport(capabilities: TransportCapabilitiesParcel?, callback: IPluginTransportCallbackV1?) =
                if (capabilities != null && callback != null) TransportResultParcel(0, "s1") else TransportResultParcel(1)
            override fun unregisterTransport(sessionId: String?): TransportResultParcel { state.close(); return TransportResultParcel(0) }
            override fun receiveMessage(sessionId: String?, channelId: String?, message: TransportMessageParcel?) =
                if (message == null) TransportResultParcel(1) else state.admitInbound(sessionId.orEmpty(), channelId.orEmpty(), message, 42)
            override fun reportDelivery(sessionId: String?, delivery: TransportDeliveryParcel?) =
                if (delivery == null) TransportResultParcel(1) else state.delivery(sessionId.orEmpty(), delivery, 42)
        }
        val extras = Bundle()
        val init = PluginInitParcel("host", 42, "plugin", extras)
        assertNull(TransportHostSupport.fromInit(init))
        extras.putString(TransportContract.EXTRA_VERSION, "1")
        extras.putBinder(TransportContract.EXTRA_CONTROL, host)
        assertNull(TransportHostSupport.fromInit(init))
        extras.putInt(TransportContract.EXTRA_VERSION, 1)
        assertSame(host, TransportHostSupport.fromInit(init))
        assertCode(0, host.registerTransport(caps, callback))
        // Explicit transactions exercise generated unmarshalling, not just local asInterface dispatch.
        fun transact(binder: android.os.IBinder, descriptor: String, transaction: Int, write: (Parcel) -> Unit): TransportResultParcel {
            val data = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(descriptor)
                write(data)
                assertTrue(binder.transact(transaction, data, reply, 0))
                reply.readException()
                return requireNotNull(reply.readTypedObject(parcelableCreator<TransportResultParcel>()))
            } finally { data.recycle(); reply.recycle() }
        }
        assertCode(0, transact(callback, "com.weartak.plugin.sdk.transport.aidl.IPluginTransportCallbackV1", 1) {
            it.writeTypedObject(request(), 0)
        })
        assertCode(0, transact(host, "com.weartak.plugin.sdk.transport.aidl.IPluginTransportHostV1", 5) {
            it.writeString("s1")
            it.writeTypedObject(update(3), 0)
        })
        assertCode(0, transact(host, "com.weartak.plugin.sdk.transport.aidl.IPluginTransportHostV1", 4) {
            it.writeString("s1"); it.writeString("radio"); it.writeTypedObject(message("inbound"), 0)
        })
        assertCode(0, callback.cancelMessage("s1", "m1"))
        callback.onSessionClosed("s1", TransportCloseReason.DISCONNECTED)
        assertCode(3, callback.sendMessage(request("m2")))
    }

    @Test
    fun legacyAidlOrderingIsUntouched() {
        val base = File("src/main/aidl/com/weartak/plugin/sdk/aidl/IWearTakPlugin.aidl").readText()
        assertFalse(base.contains("transport"))
        val methods = Regex("^    (?:void|int|Bundle|\\w+Parcel) (\\w+)\\(", RegexOption.MULTILINE)
            .findAll(base).map { it.groupValues[1] }.toList()
        assertEquals(listOf(
            "getPluginInfo", "getCapabilities", "getApiVersion", "getStatus", "initializePlugin",
            "initializePluginV2", "startPlugin", "stopPlugin", "shutdownPlugin", "registerHostCallback",
            "unregisterHostCallback", "getSettingsSchema", "getSettingsValues", "applySettings",
            "applySettingsWithResult", "onHostSettingsChanged", "getMainUiSchema", "getMainUiState",
            "invokeMainUiAction", "initializePluginV3",
        ), methods)
    }
}
